document.addEventListener("DOMContentLoaded", () => {
    const experiences = [
        {
            title: "Survey Untuk Mata Kuliah Pancasila",
            description: "Kita ke sekolah anak SD di desa kecamatan Jatinangor tapi lupa nama seklah dan desa nya apa :D",
            year: "2024",
            image: "Pancasila.jpg",
            rating: 3.9
        },
        {
            title: "Kumpul Malam Bersama Keluarga OSKM",
            description: "Pulang dari CDT day-3 langsung kumpul bersama keluarga OSKM, seru banget!!!",
            year: "2024",
            image: "oskm.jpg",
            rating: 5
        },
        {
            title: "PMB ITB 2024",
            description: "Penerimaan Mahasiswa Baru ITB tanpa topi roga yang sudah dirakit :(",
            year: "2024",
            image: "PMB.jpg",
            rating: 4.9
        },
        {
            title: "CDT 2024",
            description: "Kak abhi dan kak kila mentor CDT yang sangat seru!! game CDT juga bikin kesan yang susah buat dilupain.",
            year: "2024",
            image: "CDT.jpg",
            rating: 5
        },
        {
            title: "Arak-Arakan FTTM saat PMB",
            description: "Habis ini, suaraku habis dan batuk-batuk haha, tapi seru ;)",
            year: "2024",
            image: "arak.jpg",
            rating: 5
        },
        {
            title: "Supporteran TPB Cup 2024 AKHIRAT",
            description: "Make-upin temen-temen dari jam 5 pagi dan selesai jam 8 pagi, seru!",
            year: "2024",
            image: "support.jpg",
            rating: 5
        },
        {
            title: "Praktikum Kimia TPB resmi berakhir",
            description: "Walaupun shock peraturannya serem dan beberapa kali kena kontam, alhamdulillah masih bisa dapet A.",
            year: "2024",
            image: "labkim.jpg",
            rating: 4.7
        },
        {
            title: "Praktikum Fisika TPB resmi berakhir juga",
            description: "Selesai ini jadi langsung mau jadi asprak, bismillah deh.",
            year: "2024",
            image: "labfis.jpg",
            rating: 4.8
        },
        {
            title: "Pertemuan pertama RBL",
            description: "Ketipu, kapur mahal jelek dan kapur murah malah bagus banget.",
            year: "2024",
            image: "RBL.jpg",
            rating: 4.9
        },
        {
            title: "Akhirnya PBL beres",
            description: "PBL ini sekali rakit beres tapi banyak drama.",
            year: "2024",
            image: "PBL.jpg",
            rating: 5
        }
    ];

    const section = document.createElement("section");
    section.classList.add("experience-section");

    const title = document.createElement("h2");
    title.textContent = "Pengalaman  Seru Selama di Kampus";
    section.appendChild(title);

    const experienceContainer = document.createElement("div");
    experienceContainer.classList.add("experience-container");
    section.appendChild(experienceContainer);

    document.body.appendChild(section);

    experiences.forEach(exp => {
        const expCard = document.createElement("div");
        expCard.classList.add("experience-card");

        expCard.innerHTML = `
            <img src="${exp.image}" alt="${exp.title}">
            <h3>${exp.title}</h3>
            <p>${exp.description}</p>
            <p><strong>Tahun:</strong> ${exp.year}</p>
            <p><strong>Rating:</strong> ⭐ ${exp.rating}</p>
        `;

        experienceContainer.appendChild(expCard);
    });
});

fetch("http://localhost:3000/api/greeting")
    .then(response => response.json())
    .then(data => {
        const greetingDiv = document.createElement("div");
        greetingDiv.textContent = data.message;
        greetingDiv.style.fontSize = "20px";
        greetingDiv.style.fontWeight = "bold";
        greetingDiv.style.marginTop = "20px";
        document.body.appendChild(greetingDiv);
    })
    .catch(error => console.error("Gagal mengambil data dari API:", error));
